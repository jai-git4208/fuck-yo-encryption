"""
FuckYou Crypto - Secure encryption with FUCKYOU encoding
"""

from .core import encrypt, decrypt, FuckYouCrypto
from .encoder import FuckYouEncoder
from .noise import add_noise, remove_noise

__version__ = '1.0.0'
__all__ = [
    'encrypt', 
    'decrypt', 
    'FuckYouCrypto', 
    'FuckYouEncoder', 
    'add_noise', 
    'remove_noise'
]